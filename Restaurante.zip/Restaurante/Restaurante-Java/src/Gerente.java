
public class Gerente extends Funcionario {
	
}
