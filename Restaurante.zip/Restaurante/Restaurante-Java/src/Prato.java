
public class Prato {
	private Tamanho tamPrato;
	private String nomePrato;
	private double valorPrato;
	private int codPrato;
	
	
	public Tamanho getTamPrato() {
		return tamPrato;
	}
	public void setTamPrato(Tamanho tamPrato) {
		this.tamPrato = tamPrato;
	}
	public String getNomePrato() {
		return nomePrato;
	}
	public void setNomePrato(String nomePrato) {
		this.nomePrato = nomePrato;
	}
	public double getValorPrato() {
		return valorPrato;
	}
	public void setValorPrato(double valorPrato) {
		this.valorPrato = valorPrato;
	}
	public int getCodPrato() {
		return codPrato;
	}
	public void setCodPrato(int codPrato) {
		this.codPrato = codPrato;
	}
}
