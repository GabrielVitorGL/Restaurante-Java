
public class Bebida {
	private Tamanho tamBebida;
	private String nomeBebida;
	private double valorBebida;
	private int codBebida;
	
	
	public Tamanho getTamBebida() {
		return tamBebida;
	}
	public void setTamBebida(Tamanho tamBebida) {
		this.tamBebida = tamBebida;
	}
	public String getNomeBebida() {
		return nomeBebida;
	}
	public void setNomeBebida(String nomeBebida) {
		this.nomeBebida = nomeBebida;
	}
	public double getValorBebida() {
		return valorBebida;
	}
	public void setValorBebida(double valorBebida) {
		this.valorBebida = valorBebida;
	}
	public int getCodBebida() {
		return codBebida;
	}
	public void setCodBebida(int codBebida) {
		this.codBebida = codBebida;
	}
}
