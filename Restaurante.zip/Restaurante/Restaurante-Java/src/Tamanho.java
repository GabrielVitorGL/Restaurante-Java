
public enum Tamanho {
	PEQUENO,
	MEDIO,
	GRANDE;
}
