
public class Cozinheiro extends Funcionario {
	
}
