
public class Cliente {
	private int cpfClie;
	private String emailClie;
	private String enderecoClie;
	private int telefoneClie;
	private String nomeClie;
	
	
	public int getCpfClie() {
		return cpfClie;
	}
	public void setCpfClie(int cpfClie) {
		this.cpfClie = cpfClie;
	}
	public String getEmailClie() {
		return emailClie;
	}
	public void setEmailClie(String emailClie) {
		this.emailClie = emailClie;
	}
	public String getEnderecoClie() {
		return enderecoClie;
	}
	public void setEnderecoClie(String enderecoClie) {
		this.enderecoClie = enderecoClie;
	}
	public int getTelefoneClie() {
		return telefoneClie;
	}
	public void setTelefoneClie(int telefoneClie) {
		this.telefoneClie = telefoneClie;
	}
	public String getNomeClie() {
		return nomeClie;
	}
	public void setNomeClie(String nomeClie) {
		this.nomeClie = nomeClie;
	}
}
