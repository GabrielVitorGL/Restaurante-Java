
public class NotaFiscal {
	private int numNF;
	private double valorTotal;
	private String formaPag;
	private String dtEmi;
	
	
	public int getNumNF() {
		return numNF;
	}
	public void setNumNF(int numNF) {
		this.numNF = numNF;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public String getFormaPag() {
		return formaPag;
	}
	public void setFormaPag(String formaPag) {
		this.formaPag = formaPag;
	}
	public String getDtEmi() {
		return dtEmi;
	}
	public void setDtEmi(String dtEmi) {
		this.dtEmi = dtEmi;
	}
}
